package com.pcs.tim.myapplication;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Paint;
import android.text.method.ScrollingMovementMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import static android.content.Intent.FLAG_ACTIVITY_NEW_TASK;

/**
 * Created by Tim on 6/30/2017.
 */

public class RemarkListAdapter extends ArrayAdapter {
    private int resource;
    private LayoutInflater inflater;
    private Context context;

    public RemarkListAdapter(Context ctx, int resourceId, ArrayList<Remark> remarks) {
        super(ctx, resourceId, remarks);
        resource = resourceId;
        inflater = LayoutInflater.from(ctx);
        context = ctx;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {

        // this.position = position;
        /* create a new view of my layout and inflate it in the row */
        convertView = (LinearLayout) inflater.inflate(resource, null);

        if( position%2 == 0){
            convertView.setBackgroundColor(Color.rgb(210, 225, 250));
        }
        /* Extract the city's object to show */
        final Remark remark = (Remark) getItem(position);

        if(remark!=null) {
            TextView txtPoliceId = (TextView) convertView.findViewById(R.id.textViewPoliceID);
            if (txtPoliceId != null)
                txtPoliceId.append(": " + remark.getPoliceId());

            TextView txtFullName = convertView.findViewById(R.id.textViewRefugeeName);
            if (txtFullName != null)
                txtFullName.append(": " + remark.getRefugeeName());

            TextView txtDate = (TextView) convertView.findViewById(R.id.textViewDate);
            SimpleDateFormat sourceDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ");
            SimpleDateFormat viewDateFormat = new SimpleDateFormat("dd/MM/yyyy hh:mm a");

            try {
                Date checkTime = sourceDateFormat.parse(remark.getCheckTime());
                txtDate.append(viewDateFormat.format(checkTime));
            }catch (Exception ex){
                ex.printStackTrace();
            }

            TextView txtCheckedLocation = (TextView) convertView.findViewById(R.id.textViewCheckedLocation);
            if (remark.getLocation() != null && !remark.getLocation().equals("null"))
                txtCheckedLocation.append(": " + remark.getLocation());
            else
                txtCheckedLocation.append(": ");
            TextView txtMyrc = (TextView) convertView.findViewById(R.id.textViewMyrc);
            if (txtMyrc != null) {
                txtMyrc.append(": " + remark.getMyRc());
                txtMyrc.setPaintFlags(txtMyrc.getPaintFlags()| Paint.UNDERLINE_TEXT_FLAG);

                txtMyrc.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(getContext(), VerificationResultActivity.class);
                        intent.putExtra("inputType", "myrc");
                        intent.putExtra("inputValue", remark.getMyRc());
                        intent.putExtra("addRemark", false);
                        intent.setFlags(FLAG_ACTIVITY_NEW_TASK);
                        context.startActivity(intent);
                    }
                });
            }
            TextView txtRemark = (TextView) convertView.findViewById(R.id.textViewRemark);
            txtRemark.setMovementMethod(new ScrollingMovementMethod());
            if(!remark.getRemark().equals("null"))
                txtRemark.append(": " + remark.getRemark());
            else
                txtRemark.append(": ");
        }
        return convertView;
    }
}
