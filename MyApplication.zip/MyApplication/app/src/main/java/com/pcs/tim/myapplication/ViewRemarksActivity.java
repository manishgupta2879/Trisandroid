package com.pcs.tim.myapplication;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class ViewRemarksActivity extends AppCompatActivity {

    RemarkListAdapter remarkListAdapter;
    ArrayList<Remark> remarkArrayList;
    String myRc, enforcementId;
    ListView listViewRemark;
    TextView textViewNotFound;

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        this.finish();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_remarks);
        Intent intent = getIntent();
        myRc = intent.getStringExtra(Utilities.MY_RC);
        enforcementId = intent.getStringExtra(Utilities.POLICE_ID);
        //Log.i("Remark query", myRc + enforcementId);

        remarkArrayList = new ArrayList<>();
        listViewRemark = (ListView)findViewById(R.id.listViewRemarks);
        textViewNotFound = (TextView)findViewById(R.id.textViewNotFound);

        textViewNotFound.setVisibility(View.GONE);
        remarkArrayList.clear();
        new RetrieveRemarks().execute();

    }

    private class RetrieveRemarks extends AsyncTask<String, Void, String> {
        ProgressDialog asyncDialog = new ProgressDialog(ViewRemarksActivity.this);

        @Override
        protected void onPreExecute() {
            //set message of the dialog
            asyncDialog.setMessage(getString(R.string.loadingtype));
            //show dialog
            asyncDialog.show();
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... urls) {

            try{
                String tokenResponse = Utilities.SendTokenPostRequest();
                JSONObject jsonObject = new JSONObject(tokenResponse);
                String token = jsonObject.getString("access_token");
                String tokenType = jsonObject.getString("token_type");

                if(myRc!=null && !myRc.isEmpty()) {
                    return Utilities.SendGetRequest(Utilities.LOG + "?type=refugee&id=" + URLEncoder.encode(String.valueOf(myRc), "UTF-8"), token, tokenType);
                }else if(enforcementId != null && !enforcementId.isEmpty()){
                    return Utilities.SendGetRequest(Utilities.LOG + "?type=enforcement&id=" + URLEncoder.encode(String.valueOf(enforcementId), "UTF-8"), token, tokenType);
                }
                return null;
                /*old code
                Connection connection = Utilities.getMySqlConnection();
                Statement statement = connection.createStatement();
                String query = "";
                if(myRc!=null && !myRc.isEmpty())
                    query = "SELECT *, DATE_FORMAT(`check_time`,'%d/%m/%Y %h:%i %p') AS `time` from `tb_log` where `myrc` = '"+ myRc +"' ORDER BY `check_time` DESC";
                else if(enforcementId != null && !enforcementId.isEmpty())
                    query = "SELECT *, DATE_FORMAT(`check_time`,'%d/%m/%Y %h:%i %p') AS `time` from `tb_log` where `police_id` = '"+ enforcementId +"' ORDER BY `check_time` DESC";

                Log.i("Remark query", query);
                if(!query.equals("")) {
                    ResultSet result = statement.executeQuery(query);

                    while (result.next()) {
                        Remark remark = new Remark(result.getString("police_id"),
                                result.getString("remark"), result.getString("myrc"),
                                result.getString("location"),
                                result.getString("time"));
                        remarkArrayList.add(remark);
                    }
                    connection.close();
                    return "success";
                }
                return "fail";
                */
            }catch(Exception e){
                System.err.println("Error");
                return null;
            }
            /*HashMap<String,String> refugeeData = new HashMap<>();
            refugeeData.put(Utilities.MY_RC, myRc);
            Utilities utilities = new Utilities();
            return utilities.sendPostRequest(urls[0],refugeeData);*/

        }
        // onPostExecute displays the results of the AsyncTask.
        @Override
        protected void onPostExecute(String result) {
            try {
                /*Log.i("remark result",result);
                if (!result.equals("0")) {

                    JSONArray jsonArray = new JSONArray(result);

                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject refugeeJSON = jsonArray.getJSONObject(i);
                        Remark remark = new Remark(refugeeJSON.getString(Utilities.LOG_POLICE_ID),
                                refugeeJSON.getString(Utilities.LOG_REMARK), myRc,
                                refugeeJSON.getString(Utilities.LOCATION),
                                refugeeJSON.getString(Utilities.CHECK_TIME));
                        remarkArrayList.add(remark);
                    }
*/
                if( result != null ){
                    asyncDialog.dismiss();
                    JSONArray jsonArray = new JSONArray(result);
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject refugeeJSON = jsonArray.getJSONObject(i);
                        Remark remark = new Remark(refugeeJSON.getString(Utilities.LOG_POLICE_ID),
                                refugeeJSON.getString(Utilities.LOG_REMARK),
                                refugeeJSON.getString(Utilities.MY_RC),
                                refugeeJSON.getString(Utilities.LOCATION),
                                refugeeJSON.getString(Utilities.CHECK_TIME),
                                refugeeJSON.getString(Utilities.FULL_NAME));
                        remarkArrayList.add(remark);
                    }
                    if(myRc!=null && !myRc.isEmpty())
                        remarkListAdapter = new RemarkListAdapter(getBaseContext(),R.layout.refugee_remark_list_item,remarkArrayList);
                    else
                        remarkListAdapter = new RemarkListAdapter(getBaseContext(),R.layout.remark_list_item,remarkArrayList);

                    listViewRemark.setAdapter(remarkListAdapter);
                    remarkListAdapter.notifyDataSetChanged();

                }
                else{
                    asyncDialog.dismiss();
                    textViewNotFound.setVisibility(View.VISIBLE);
                }
            }
            catch(Exception ex) {
                ex.printStackTrace();
            }
        }
    }
}
