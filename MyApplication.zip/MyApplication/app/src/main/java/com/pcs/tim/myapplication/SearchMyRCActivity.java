package com.pcs.tim.myapplication;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Geocoder;
import android.location.Location;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Process;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.fitness.data.Device;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;

import org.apache.commons.net.util.Base64;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

public class SearchMyRCActivity extends AppCompatActivity {

    ImageButton buttonSearchMyRC;

    private TextView textViewNotFound;
    private TextView textViewName;
    private TextView textViewMyRC;
    private TextView textViewCategory;
    private TextView textViewUnhcr;
    private TextView textViewDob;
    private TextView textViewGender;
    private TextView textViewReligion;
    private TextView textViewCountry;
    private TextView textViewEthnic;
    private TextView textViewAddress;
    private TextView textViewDateIssue;
    private TextView textViewDateExpiry;
    private TextView textViewExpired;
    private TextView textViewState;
    private TextView textViewMobile;
    private TextView textViewComapnyName;
    private TextView textViewEmployerName;
    private TextView textViewEmployerContact;
    private TextView textViewJobSector;
    private TextView textViewWorkLocation;
    private TextView textViewWorkDesc;
    private TextView textViewLengthOfWork;
    private TextView textViewLengthOfStay;
    private TextView textViewCurrentPay;
    private TextView textViewApprovalStatus;
    private TextView textViewCardValid, textViewCardPending;
    private ImageView imageViewPhoto;
    private FrameLayout frameLayout;
    private EditText editTextSearchMyRC1;
    private EditText editTextSearchMyRC2;
    private EditText editTextSearchMyRC3;
    private Button buttonAddRemark;
    private Button buttonViewRemarks;
    private static final char space = '-';
    private TextView textViewUNCaseNo, textViewRefugeeGroup, textViewMarital, textViewBirthPlace, textViewFamilySize, textViewPassport,
            textViewEmergencyPerson, textViewEmergencyContact, textViewComRegNo, textViewApproveDate;

    String name = "", category = "", unhcr = "", dob = "", gender = "", address = "", country = "",
            religion = "", ethnicGroup = "", issueDate = "", expiredDate = "", employerName = "",
            employerContact = "", mobileNo = "", companyName = "", state = "", jobSector = "",
            workLocation = "",workDesc = "", approvalStatus = "", unhcrCaseNo = "", refugeeGroup = "",
            maritalStatus = "", birthPlace = "", familySize = "", passportNo = "", emergencyPerson = "",
            emergencyContact = "", companyRegNo = "", approvalDate = "", myRc = "" ;
    int lengthOfWork, lengthOfStay;
    double currentPay;
    byte[] photoBytes;
    String dbResult;

    private int log_id;
    private float lat = 0;
    private float lng = 0;
    String locationAddress = "No GPS";
    protected Location mLastLocation;
    private FusedLocationProviderClient mFusedLocationClient;
    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_my_rc);

        sharedPreferences = getSharedPreferences(Utilities.MY_RC_SHARE_PREF, MODE_PRIVATE);

        textViewNotFound = (TextView)findViewById(R.id.textViewNotFound);
        editTextSearchMyRC1 = (EditText)findViewById(R.id.editTextMyRC1);
        editTextSearchMyRC2 = (EditText)findViewById(R.id.editTextMyRC2);
        editTextSearchMyRC3 = (EditText)findViewById(R.id.editTextMyRC3);
        frameLayout = (FrameLayout) findViewById(R.id.verification_result);
        textViewExpired = (TextView)findViewById(R.id.textViewCardExpired);
        textViewCardPending = (TextView)findViewById(R.id.textViewCardPending);
        textViewCardValid = (TextView)findViewById(R.id.textViewCardValid);
        buttonSearchMyRC = (ImageButton)findViewById(R.id.buttonSearchMyRC);
        textViewMyRC = (TextView)findViewById(R.id.textViewMyrc);
        textViewName = (TextView)findViewById(R.id.textViewName);
        textViewAddress = (TextView)findViewById(R.id.textViewAddress);
        textViewCategory = (TextView)findViewById(R.id.textViewCategory);
        textViewCountry  = (TextView)findViewById(R.id.textViewCountry);
        textViewDateExpiry = (TextView)findViewById(R.id.textViewDateExpiry);
        textViewDateIssue = (TextView)findViewById(R.id.textViewDateIssue);
        textViewEthnic = (TextView)findViewById(R.id.textViewEthnic);
        textViewDob = (TextView)findViewById(R.id.textViewDOB);
        textViewReligion = (TextView)findViewById(R.id.textViewReligion);
        textViewUnhcr = (TextView)findViewById(R.id.textViewUNHCR);
        textViewGender = (TextView)findViewById(R.id.textViewGender);
        textViewState = (TextView)findViewById(R.id.textViewState);
        textViewMobile = (TextView)findViewById(R.id.textViewMobileNo);
        textViewComapnyName = (TextView)findViewById(R.id.textViewCompanyName);
        textViewEmployerName = (TextView)findViewById(R.id.textViewEmployerName);
        textViewEmployerContact = (TextView)findViewById(R.id.textViewEmployerContact);
        textViewJobSector = (TextView)findViewById(R.id.textViewJobSector);
        textViewWorkLocation = (TextView)findViewById(R.id.textViewWorkLocation);
        textViewWorkDesc = (TextView)findViewById(R.id.textViewWorkDescription);
        textViewLengthOfWork = (TextView)findViewById(R.id.textViewLengthOfWork);
        textViewLengthOfStay = (TextView)findViewById(R.id.textViewLengthOfStay);
        textViewCurrentPay = (TextView)findViewById(R.id.textViewCurrentPay);
        textViewApprovalStatus = (TextView)findViewById(R.id.textViewApprovalStatus);
        imageViewPhoto = (ImageView)findViewById(R.id.imageViewPhoto);
        buttonAddRemark = (Button) findViewById(R.id.btnAddRemark);
        buttonViewRemarks = (Button)findViewById(R.id.btnViewRemark);
        textViewUNCaseNo = (TextView)findViewById(R.id.textViewUNHCRCaseNo);
        textViewRefugeeGroup = (TextView)findViewById(R.id.textViewRefugeeGroup);
        textViewMarital = (TextView)findViewById(R.id.textViewMarital);
        textViewBirthPlace = (TextView)findViewById(R.id.textViewBirthPlace);
        textViewFamilySize = (TextView)findViewById(R.id.textViewFamilySize);
        textViewPassport = (TextView)findViewById(R.id.textViewPassportNo);
        textViewEmergencyPerson = (TextView)findViewById(R.id.textViewEmergencyPerson);
        textViewEmergencyContact = (TextView)findViewById(R.id.textViewEmergencyContact);
        textViewComRegNo = (TextView)findViewById(R.id.textViewCompanyRegNo);
        textViewApproveDate = (TextView)findViewById(R.id.textViewDateApprove);

        editTextSearchMyRC1.requestFocus();
        //show keyboard
        InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, 0);

        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        buttonViewRemarks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myRc = textViewMyRC.getText().toString();
                Intent intentRemark = new Intent(getApplicationContext(), ViewRemarksActivity.class);
                intentRemark.putExtra(Utilities.MY_RC, myRc);
                startActivity(intentRemark);
            }
        });

        buttonAddRemark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(checkPermission(android.Manifest.permission.ACCESS_FINE_LOCATION, Process.myPid(), Process.myUid()) == PackageManager.PERMISSION_GRANTED) {
                    String myRc = textViewMyRC.getText().toString();
                    AddRemarksFragment addRemarksFragment = AddRemarksFragment.newInstance(myRc, log_id);
                    addRemarksFragment.show(getSupportFragmentManager(), getString(R.string.add_remark));
                }else{
                    ActivityCompat.requestPermissions(SearchMyRCActivity.this,
                            new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION},
                            1);
                }
            }
        });
        editTextSearchMyRC1.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count,
                                          int after) {
                // TODO Auto-generated method stub

            }

            @Override
            public void afterTextChanged(Editable s) {
                if(s.length() == 3)
                    editTextSearchMyRC2.requestFocus();

            }
        });

        editTextSearchMyRC2.addTextChangedListener(new TextWatcher() {

               @Override
               public void onTextChanged(CharSequence s, int start, int before, int count) {

               }

               @Override
               public void beforeTextChanged(CharSequence s, int start, int count,
                                             int after) {
                   // TODO Auto-generated method stub

               }

               @Override
               public void afterTextChanged(Editable s) {
                   if(s.length() == 6){
                       editTextSearchMyRC3.requestFocus();
                   }
               }
        });
        buttonSearchMyRC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                textViewNotFound.setVisibility(View.GONE);
                if (checkMyRc()) {
                    myRc = editTextSearchMyRC1.getText().toString() + space +
                             editTextSearchMyRC2.getText().toString() + space +
                             editTextSearchMyRC3.getText().toString();
                    //hide keyboard
                    InputMethodManager imm = (InputMethodManager)getSystemService(
                            Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(editTextSearchMyRC3.getWindowToken(), 0);
                    new RetrieveRefugeeData().execute();
                }
            }
        });
    }

    private boolean checkMyRc(){
        if(editTextSearchMyRC1.getText().toString().length() < 3)
        {
            editTextSearchMyRC1.setError("Please insert 3 characters");
            editTextSearchMyRC1.requestFocus();

        }else if (editTextSearchMyRC2.getText().toString().length() < 6){

            editTextSearchMyRC2.setError("Please insert 6 characters");
            editTextSearchMyRC2.requestFocus();

        }else if (editTextSearchMyRC3.getText().toString().length() < 7){
            editTextSearchMyRC3.setError("Please insert 7 characters");
            editTextSearchMyRC3.requestFocus();
        }
        else
            return true;
        return false;
    }

    private class RetrieveRefugeeData extends AsyncTask<String, Void, String> {
        ProgressDialog asyncDialog = new ProgressDialog(SearchMyRCActivity.this);

        @Override
        protected void onPreExecute() {
            //set message of the dialog
            asyncDialog.setMessage(getString(R.string.loadingtype));
            //show dialog
            asyncDialog.show();
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... urls) {
            try{

                String tokenResponse = Utilities.SendTokenPostRequest();
                JSONObject jsonObject = new JSONObject(tokenResponse);
                String token = jsonObject.getString("access_token");
                String tokenType = jsonObject.getString("token_type");

                String result = Utilities.SendGetRequest(Utilities.REFUGEE + "?inputType=myrc" + "&value=" + URLEncoder.encode(String.valueOf(myRc), "UTF-8"), token, tokenType);

                JSONArray arrayResult = new JSONArray(result);
                JSONObject objectResult = arrayResult.getJSONObject(0);


                locationAddress = sharedPreferences.getString("locationAddress", "No GPS");
                lat = sharedPreferences.getFloat("lat", 0);
                lng = sharedPreferences.getFloat("lng", 0);
                HashMap<String, String> data = new HashMap<>();
                data.put(Utilities.POLICE_ID, sharedPreferences.getString(Utilities.LOGIN_POLICE_ID, null));
                data.put(Utilities.MY_RC, objectResult.getString(Utilities.MY_RC));
                data.put(Utilities.LOG_REMARK, "");
                data.put(Utilities.LOCATION, locationAddress);
                data.put(Utilities.LATITUDE, Float.toString(lat));
                data.put(Utilities.LONGITUDE, Float.toString(lng));
                Utilities.sendPostRequest(Utilities.LOG, data, token, tokenType);


                return result;
//                Connection connection = Utilities.getMySqlConnection();
//                Statement statement = connection.createStatement();
//
//                String query = "Select `myrc`, `unhcrid`,`unhcrCaseNo`, `refugeeGroup`, `fullName`, `category`, `gender`, `address`, " +
//                        "DATE_FORMAT(`dob`,'%d/%m/%Y') AS `dob`, `countryOfOrigin`, `religion`, `maritalStatus`, `ethincGroup`, " +
//                        "`address`, `createdTime`, `placeOfBirth`, `familySize`, `passportNo`, `emergencyContact`, `emergencyNo`, `empRegNo`, " +
//                        "DATE_FORMAT(`cardExpiredDate`,'%d/%m/%Y') AS `expiredDate`, `photo`, `state`, `approvalTime`, " +
//                        "`workLocation`, `mobileNo`, `empName`, `empContactName`, `empContactNo`, `workSector`, " +
//                        "`workDescription`, `lengthOfWork`, `lengthOfStay`, `currentPay`, `isApprove` from `tb_register` " +
//                        "where `myrc` = '"+ myRc +"'";
//
//                ResultSet result = statement.executeQuery(query);
//                if (result.next()){
//                    name = result.getString("fullName");
//                    myRc = result.getString("myrc");
//                    category = result.getString("category");
//                    unhcr = result.getString("unhcrid");
//                    dob = result.getString("dob");
//                    gender = result.getString("gender");
//                    address = result.getString("address");
//                    country = result.getString("countryOfOrigin");
//                    religion = result.getString("religion");
//                    ethnicGroup = result.getString("ethincGroup");
//                    issueDate = result.getString("createdTime");
//                    Date date1= new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").parse(issueDate);
//                    issueDate = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss a").format(date1);
//                    expiredDate = result.getString("expiredDate");
//                    //nt blobLength = (int)result.getBlob("photo").length();
//                    photoBytes = result.getBytes("photo");
//                    employerName = result.getString("empContactName");
//                    employerContact = result.getString("empContactNo");
//                    mobileNo = result.getString("mobileNo");
//                    companyName = result.getString("empName");
//                    state = result.getString("state");
//                    jobSector = result.getString("workSector");
//                    workLocation = result.getString("workLocation");
//                    workDesc = result.getString("workDescription");
//                    lengthOfWork = result.getInt("lengthOfWork");
//                    lengthOfStay = result.getInt("lengthOfStay");
//                    currentPay = result.getDouble("currentPay");
//                    approvalStatus = result.getString("isApprove");
////                    if(approvalStatus != null){
////                        if(approvalStatus.equals("0"))
////                            approvalStatus = "Rejected";
////                        else
////                            approvalStatus = "Approved";
////                    }
////                    else
////                        approvalStatus = "Pending";
//                    unhcrCaseNo = result.getString("unhcrCaseNo");
//                    refugeeGroup = result.getString("refugeeGroup");
//                    maritalStatus = result.getString("maritalStatus");
//                    birthPlace = result.getString("placeOfBirth");
//                    familySize = result.getString("familySize");
//                    passportNo = result.getString("passportNo");
//                    emergencyPerson = result.getString("emergencyContact");
//                    emergencyContact = result.getString("emergencyNo");
//                    companyRegNo = result.getString("empRegNo");
//                    approvalDate = result.getString("approvalTime");
//                    dbResult = "success";
//
//                    locationAddress = sharedPreferences.getString("locationAddress","No GPS");
//                    lat = sharedPreferences.getFloat("lat",0);
//                    lng = sharedPreferences.getFloat("lng",0);
//
//                    query = "INSERT INTO `tb_log`(`police_id`, `myrc`, `remark`, `location`, `lat`, `lng`)"
//                            + " VALUES (?, ?, ?, ?, ?, ?)";
//
//                    // create the mysql insert preparedstatement
//                    PreparedStatement preparedStmt = connection.prepareStatement(query);
//                    preparedStmt.setString (1, sharedPreferences.getString(Utilities.LOGIN_POLICE_ID, null));
//                    preparedStmt.setString (2, myRc);
//                    preparedStmt.setString (3, "");
//                    preparedStmt.setString(4, locationAddress);
//                    preparedStmt.setFloat (5, lat);
//                    preparedStmt.setFloat(6, lng);
//
//                    // execute the preparedstatement
//                    log_id = preparedStmt.executeUpdate();
//
//                    connection.close();
//                }
//                else {
//                    dbResult = "fail";
//                }
            }catch(Exception e){
                return null;
                //System.err.println("Error");
            }
        }
        // onPostExecute displays the results of the AsyncTask.
        @Override
        protected void onPostExecute(String result) {
            try {
                asyncDialog.dismiss();
                // Log.i("Refugee Result", result);
                if(result != null) {
                    textViewNotFound.setVisibility(View.GONE);
                    buttonAddRemark.setVisibility(View.VISIBLE);
                    frameLayout.setVisibility(View.VISIBLE);

                    JSONArray jsonArray = new JSONArray(result);
                    JSONObject refugeeJSON = jsonArray.getJSONObject(0);
                    byte[] base64Encoded = Base64.decodeBase64(refugeeJSON.getString(Utilities.PHOTO));
                    if (base64Encoded != null) {
                        Bitmap photo = BitmapFactory.decodeByteArray(base64Encoded, 0, base64Encoded.length);
                        imageViewPhoto.setImageBitmap(photo);
                    }

                    name = refugeeJSON.getString("fullName");
                    myRc = refugeeJSON.getString("myrc");
                    category = refugeeJSON.getString("category");
                    unhcr = refugeeJSON.getString("unhcrID");
                    dob = refugeeJSON.getString("dob");
                    Date dobDate = new SimpleDateFormat("yyyy-MM-dd").parse(dob);
                    dob = new SimpleDateFormat("dd-MM-yyyy").format(dobDate);
                    gender = refugeeJSON.getString("gender");
                    address = refugeeJSON.getString("address");
                    country = refugeeJSON.getString("countryOfOrigin");
                    religion = refugeeJSON.getString("religion");
                    ethnicGroup = refugeeJSON.getString("ethincGroup");
                    issueDate = refugeeJSON.getString("createdTime");
                    if(issueDate!=null && !issueDate.equals("null")) {
                        Date date1 = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ss").parse(issueDate);
                        issueDate = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss a").format(date1);
                    }
                    expiredDate = refugeeJSON.getString("cardExpiredDate");
                    if(expiredDate!=null && !expiredDate.equals("null")) {
                        Date date1 = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ss").parse(expiredDate);
                        expiredDate = new SimpleDateFormat("dd-MM-yyyy").format(date1);
                    }
                    employerName = refugeeJSON.getString("empContactName");
                    employerContact = refugeeJSON.getString("empContactNo");
                    mobileNo = refugeeJSON.getString("mobileNo");
                    companyName = refugeeJSON.getString("empName");
                    state = refugeeJSON.getString("state");
                    jobSector = refugeeJSON.getString("workSector");
                    workLocation = refugeeJSON.getString("workLocation");
                    workDesc = refugeeJSON.getString("workDescription");
                    lengthOfWork = Integer.parseInt(refugeeJSON.getString("lengthOfWork"));
                    lengthOfStay = Integer.parseInt(refugeeJSON.getString("lengthOfStay"));
                    currentPay = Double.parseDouble(refugeeJSON.getString("currentPay"));
                    approvalStatus = refugeeJSON.getString("isPrint");
//                    if (approvalStatus != null) {
//                        if (approvalStatus.equals("0"))
//                            approvalStatus = "Rejected";
//                        else
//                            approvalStatus = "Approved";
//                    } else
//                        approvalStatus = "Pending";
                    unhcrCaseNo = refugeeJSON.getString("unhcrCaseNo");
                    refugeeGroup = refugeeJSON.getString("refugeeGroup");
                    maritalStatus = refugeeJSON.getString("maritalStatus");
                    birthPlace = refugeeJSON.getString("placeOfBirth");
                    familySize = refugeeJSON.getString("familySize");
                    passportNo = refugeeJSON.getString("passportNo");
                    emergencyPerson = refugeeJSON.getString("emergencyContact");
                    emergencyContact = refugeeJSON.getString("emergencyNo");
                    companyRegNo = refugeeJSON.getString("empRegNo");
                    approvalDate = refugeeJSON.getString("approvalTime");
                    if(approvalDate!=null && !approvalDate.equals("null")) {
                        Date approvalDate1 = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ss").parse(approvalDate);
                        approvalDate = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss a").format(approvalDate1);
                        textViewApproveDate.setText(approvalDate);
                    }
                    textViewMyRC.setText(myRc);
                    textViewName.setText(name);
                    textViewDateIssue.setText(issueDate);
                    textViewEthnic.setText(ethnicGroup);
                    textViewCategory.setText(category);
                    if(!expiredDate.isEmpty() && !expiredDate.equals("null"))
                        textViewDateExpiry.setText(expiredDate);
                    textViewAddress.setText(address);
                    textViewGender.setText(gender);
                    textViewDob.setText(dob);
                    textViewCountry.setText(country);
                    textViewUnhcr.setText(unhcr);
                    textViewReligion.setText(religion);
                    textViewState.setText(state);
                    textViewMobile.setText(mobileNo);
                    textViewComapnyName.setText(companyName);
                    textViewEmployerName.setText(employerName);
                    textViewEmployerContact.setText(employerContact);
                    textViewJobSector.setText(jobSector);
                    textViewWorkLocation.setText(workLocation);
                    textViewWorkDesc.setText(workDesc);
                    if (lengthOfWork != 0)
                        textViewLengthOfWork.setText(Integer.toString(lengthOfWork));
                    if (lengthOfStay != 0)
                        textViewLengthOfStay.setText(Integer.toString(lengthOfStay));
                    if (currentPay != 0)
                        textViewCurrentPay.setText("RM " + (String.format("%.2f", currentPay)));

                    if (approvalStatus != null && !approvalStatus.isEmpty()) {
                        switch (approvalStatus) {
                            case "false":
                                approvalStatus = "Rejected";
                                textViewExpired.setText(approvalStatus);
                                textViewExpired.setVisibility(View.VISIBLE);
                                break;
                            case "true":
                                approvalStatus = "Approved";
                                if (expiredDate != null && !expiredDate.isEmpty() && !expiredDate.equals("null")) {
                                    Date dateExpired = new SimpleDateFormat("dd-MM-yyyy").parse(expiredDate);
                                    Calendar expiredDateCal = Calendar.getInstance();
                                    expiredDateCal.setTime(dateExpired);
                                    Calendar cal = Calendar.getInstance();

                                    //Log.i("Expired & current", expiredDate.toString()+cal.toString());
                                    if (cal.getTimeInMillis() > expiredDateCal.getTimeInMillis()) {
                                        textViewExpired.setVisibility(View.VISIBLE);
                                        //Log.i("Expired", "true");
                                    } else
                                        textViewCardValid.setVisibility(View.VISIBLE);
                                } else {
                                    textViewCardValid.setText("Approved");
                                    textViewCardValid.setVisibility(View.VISIBLE);
                                }
                                break;
                            default:
                                approvalStatus = "Pending";
                                textViewCardPending.setVisibility(View.VISIBLE);
                                break;
                        }
                    } else {
                        approvalStatus = "Pending";
                        textViewCardPending.setVisibility(View.VISIBLE);
                    }
                    textViewApprovalStatus.setText(approvalStatus);
                    textViewUNCaseNo.setText(unhcrCaseNo);
                    textViewRefugeeGroup.setText(refugeeGroup);
                    textViewMarital.setText(maritalStatus);
                    textViewBirthPlace.setText(birthPlace);
                    textViewFamilySize.setText(familySize);
                    textViewPassport.setText(passportNo);
                    textViewEmergencyPerson.setText(emergencyPerson);
                    textViewEmergencyContact.setText(emergencyContact);
                    textViewComRegNo.setText(companyRegNo);

                } else {
                    textViewNotFound.setVisibility(View.VISIBLE);
                }
//                    Bitmap photo = BitmapFactory.decodeByteArray(photoBytes, 0 ,photoBytes.length);
//                    imageViewPhoto.setImageBitmap(photo);
//
//                    textViewMyRC.setText(myRc);
//                    textViewName.setText(name);
//                    textViewDateIssue.setText(issueDate);
//                    textViewEthnic.setText(ethnicGroup);
//                    textViewCategory.setText(category);
//                    textViewDateExpiry.setText(expiredDate);
//                    textViewAddress.setText(address);
//                    textViewGender.setText(gender);
//                    textViewDob.setText(dob);
//                    textViewCountry.setText(country);
//                    textViewUnhcr.setText(unhcr);
//                    textViewReligion.setText(religion);
//                    textViewState.setText(state);
//                    textViewMobile.setText(mobileNo);
//                    textViewComapnyName.setText(companyName);
//                    textViewEmployerName.setText(employerName);
//                    textViewEmployerContact.setText(employerContact);
//                    textViewJobSector.setText(jobSector);
//                    textViewWorkLocation.setText(workLocation);
//                    textViewWorkDesc.setText(workDesc);
//                    if(lengthOfWork != 0)
//                        textViewLengthOfWork.setText(Integer.toString(lengthOfWork));
//                    if(lengthOfStay != 0)
//                        textViewLengthOfStay.setText(Integer.toString(lengthOfStay));
//                    if(currentPay != 0)
//                        textViewCurrentPay.setText("RM " + (String.format("%.2f", currentPay)));
//
//                    if(approvalStatus!=null) {
//                        switch (approvalStatus) {
//                            case "0":
//                                approvalStatus = "Rejected";
//                                textViewExpired.setText(approvalStatus);
//                                textViewExpired.setVisibility(View.VISIBLE);
//                                break;
//                            case "1":
//                                approvalStatus = "Approved";
//                                if (expiredDate != null) {
//                                    Date date1 = new SimpleDateFormat("dd/MM/yyyy").parse(expiredDate);
//                                    Calendar expiredDate = Calendar.getInstance();
//                                    expiredDate.setTime(date1);
//                                    Calendar cal = Calendar.getInstance();
//
//                                    //Log.i("Expired & current", expiredDate.toString()+cal.toString());
//                                    if (cal.getTimeInMillis() > expiredDate.getTimeInMillis()) {
//                                        textViewExpired.setVisibility(View.VISIBLE);
//                                        Log.i("Expired", "true");
//                                    } else
//                                        textViewCardValid.setVisibility(View.VISIBLE);
//                                }else{
//                                    textViewCardValid.setText("Approved");
//                                    textViewCardValid.setVisibility(View.VISIBLE);
//                                }
//                                break;
//                        }
//                    }
//                    else{
//                        approvalStatus = "Pending";
//                        textViewCardPending.setVisibility(View.VISIBLE);
//                    }
//                    textViewApprovalStatus.setText(approvalStatus);
////                    if(expiredDate != null){
////                        Date date1 = new SimpleDateFormat("dd/MM/yyyy").parse(expiredDate);
////                        Calendar expiredDate = Calendar.getInstance();
////                        expiredDate.setTime(date1);
////                        Calendar cal = Calendar.getInstance();
////                        //Log.i("Expired & current", expiredDate.toString()+cal.toString());
////                        if(cal.getTimeInMillis() > expiredDate.getTimeInMillis()){
////                            textViewExpired.setVisibility(View.VISIBLE);
////                            Log.i("Expired", "true");
////                        }else
////                            textViewCardValid.setVisibility(View.VISIBLE);
////                    }
//                    textViewUNCaseNo.setText(unhcrCaseNo);
//                    textViewRefugeeGroup.setText(refugeeGroup);
//                    textViewMarital.setText(maritalStatus);
//                    textViewBirthPlace.setText(birthPlace);
//                    textViewFamilySize.setText(familySize);
//                    textViewPassport.setText(passportNo);
//                    textViewEmergencyPerson.setText(emergencyPerson);
//                    textViewEmergencyContact.setText(emergencyContact);
//                    textViewComRegNo.setText(companyRegNo);
//                    textViewApproveDate.setText(approvalDate);
//                }
//                else{
//                    textViewNotFound.setVisibility(View.VISIBLE);
//                }
            }
            catch(Exception ex) {
                textViewNotFound.setVisibility(View.VISIBLE);
                ex.printStackTrace();
            }
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        this.finish();
    }
}
