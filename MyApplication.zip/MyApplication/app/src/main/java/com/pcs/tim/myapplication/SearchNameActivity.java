package com.pcs.tim.myapplication;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.annotation.UiThread;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.mysql.jdbc.Util;

import org.apache.commons.net.util.Base64;
import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;

public class SearchNameActivity extends AppCompatActivity {

    ListView refugeeNameListView;
    ArrayList<Refugee> refugeeArrayList;
    ImageView buttonSearchName;
    EditText editTextName;
    String query;
    RefugeeListAdapter refugeeListAdapter;
    TextView textViewNotFound;

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        this.finish();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_name);

        Intent intent = getIntent();
        query = intent.getStringExtra("query");

        refugeeArrayList = new ArrayList<>();
        refugeeNameListView = (ListView) findViewById(R.id.listViewRefugeeNames);
        textViewNotFound = (TextView)findViewById(R.id.textViewNotFound);

        refugeeNameListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Refugee refugee = refugeeArrayList.get(position);
                String myRC = refugee.getMyRC();
                Intent intent = new Intent(getApplicationContext(), VerificationResultActivity.class);
                intent.putExtra("inputType", "myrc");
                intent.putExtra("inputValue", myRC);
                //intent.putExtra(Utilities.MY_RC, myRC);
                startActivity(intent);
            }
        });

        buttonSearchName = (ImageView)findViewById(R.id.buttonSearchName);
        editTextName = (EditText)findViewById(R.id.editTextName);
        buttonSearchName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               // if (Utilities.hasActiveInternetConnection(getApplicationContext())) {
                    query = editTextName.getText().toString();

                    if (query.length() < 5) {
                        editTextName.setError(getString(R.string.search_name_err));
                        editTextName.requestFocus();
                    } else {
                        textViewNotFound.setVisibility(View.GONE);
                        refugeeArrayList.clear();
                        new SearchRefugeeName().execute();
                    }

               // }
            }
        });
        if(query!=null && !query.isEmpty()){
            editTextName.setText(query);
            textViewNotFound.setVisibility(View.GONE);
            refugeeArrayList.clear();
            new SearchRefugeeName().execute();
        }
    }

    private class SearchRefugeeName extends AsyncTask<String, Void, String> {
        ProgressDialog asyncDialog = new ProgressDialog(SearchNameActivity.this);

        @Override
        protected void onPreExecute() {
            //set message of the dialog
            asyncDialog.setMessage(getString(R.string.loadingtype));
            //show dialog
            asyncDialog.setCancelable(false);
            asyncDialog.show();
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... urls) {
            try{
                String tokenResponse = Utilities.SendTokenPostRequest();
                JSONObject jsonObject = new JSONObject(tokenResponse);
                String token = jsonObject.getString("access_token");
                String tokenType = jsonObject.getString("token_type");

                return Utilities.SendGetRequest(Utilities.REFUGEE + "?query=" + URLEncoder.encode(String.valueOf(query), "UTF-8") + "&searchnameonly=false", token, tokenType);
            }catch(Exception e){
                return null;
            }
            /*HashMap<String,String> refugeeData = new HashMap<>();
            refugeeData.put("name",name);
            Utilities utilities = new Utilities();
            return utilities.sendPostRequest(urls[0],refugeeData);*/
        }
        // onPostExecute displays the results of the AsyncTask.
        @Override
        protected void onPostExecute(String result) {
            try {
                if (result != null) {
                    asyncDialog.dismiss();
                    JSONArray jsonArray = new JSONArray(result);

                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject refugeeJSON = jsonArray.getJSONObject(i);

                        byte[] base64Encoded = Base64.decodeBase64(refugeeJSON.getString(Utilities.PHOTO));
                        Refugee refugee = new Refugee(refugeeJSON.getString(Utilities.FULL_NAME),
                                refugeeJSON.getString(Utilities.MY_RC),
                                base64Encoded,refugeeJSON.getString(Utilities.COUNTRY),
                                refugeeJSON.getString(Utilities.CATEGORY));
                       // Log.i("photo bytes", new String(base64Encoded));
                        //Log.i("photo", refugeeJSON.getString(Utilities.PHOTO));
                        refugeeArrayList.add(refugee);
                    }

                    refugeeListAdapter = new RefugeeListAdapter(getBaseContext(),R.layout.search_list_item,refugeeArrayList);
                    refugeeNameListView.setAdapter(refugeeListAdapter);
                    refugeeListAdapter.notifyDataSetChanged();

                }
                else{
                    asyncDialog.dismiss();
                    textViewNotFound.setVisibility(View.VISIBLE);
                }
            }
            catch(Exception ex) {
                asyncDialog.dismiss();
                Log.i("HERE", ex.getMessage());
                textViewNotFound.setVisibility(View.VISIBLE);
                ex.printStackTrace();
            }
        }
    }
}
