package com.pcs.tim.myapplication;

/**
 * Created by Tim on 6/30/2017.
 */

class Remark {

    private String policeId;
    private String remark;
    private String myRc;
    private String location;
    private String checkTime;
    private String refugeeName;

    Remark(String policeId, String remark, String myRc, String location, String checkTime, String refugeeName) {
        this.policeId = policeId;
        this.remark = remark;
        this.myRc = myRc;
        this.location = location;
        this.checkTime = checkTime;
        this.refugeeName = refugeeName;
    }
    String getRefugeeName() {
        return refugeeName;
    }

    String getPoliceId() {
        return policeId;
    }

    String getRemark() {
        return remark;
    }

    String getMyRc() {
        return myRc;
    }

    String getLocation() {
        return location;
    }

    String getCheckTime() {
        return checkTime;
    }

}
