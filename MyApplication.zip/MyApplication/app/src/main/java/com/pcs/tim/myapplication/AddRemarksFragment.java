package com.pcs.tim.myapplication;


import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.location.Location;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.HashMap;


/**
 * A simple {@link Fragment} subclass.
 * Use the {@link AddRemarksFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class AddRemarksFragment extends DialogFragment {
    private static final String MY_RC = "my_rc";
    private static final String LOG_ID = "log_id";

    SharedPreferences sharedPreferences;
    private float lat;
    private float lng;
    private String policeId;
    private String myRc;
    private int log_id;
    private String remark;
    private String address;

    private String mAddressOutput;
    protected Location mLastLocation;
   // private AddressResultReceiver mResultReceiver;

    EditText editTextRemark;
    EditText editTextLocation;
    Button buttonAddRemark;

    public AddRemarksFragment() {
    }

    public static AddRemarksFragment newInstance(String myRc, int log_id) {
        AddRemarksFragment fragment = new AddRemarksFragment();
        Bundle args = new Bundle();
        args.putString(MY_RC, myRc);
        args.putInt(LOG_ID,log_id);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            myRc = getArguments().getString(MY_RC);
            log_id = getArguments().getInt(LOG_ID);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_add_remarks, container, false);
        getDialog().requestWindowFeature(Window.FEATURE_NO_TITLE);
        buttonAddRemark = (Button)view.findViewById(R.id.btnSubmitRemark);
        editTextRemark = (EditText)view.findViewById(R.id.editTextRemark);
        editTextLocation = (EditText)view.findViewById(R.id.editTextCurrentLocation);
        editTextLocation.setEnabled(false);
        return view;
    }

    @Override
    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);

        sharedPreferences = getActivity().getSharedPreferences(Utilities.MY_RC_SHARE_PREF, Context.MODE_PRIVATE);
        mAddressOutput = sharedPreferences.getString("locationAddress", null);
        policeId = sharedPreferences.getString(Utilities.LOGIN_POLICE_ID, null);
        lat = sharedPreferences.getFloat("lat",0);
        lng = sharedPreferences.getFloat("lng",0);

        if( mAddressOutput == null )
            editTextLocation.setEnabled(true);
        else
            editTextLocation.setText(mAddressOutput);
        buttonAddRemark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                editTextRemark.setError(null);
                remark = editTextRemark.getText().toString();
                address = editTextLocation.getText().toString();

                if(remark.trim().isEmpty()) {
                    editTextRemark.setError(getString(R.string.err_field_required));
                    editTextRemark.requestFocus();
                }
                else
                if(address.trim().isEmpty()){
                    editTextLocation.setError(getString(R.string.err_field_required));
                    editTextLocation.requestFocus();
                }
                else
                    new InsertLog().execute();
            }
        });

       // mResultReceiver = new AddressResultReceiver(new Handler());
       // FusedLocationProviderClient mFusedLocationClient = LocationServices.getFusedLocationProviderClient(getContext());

        /*if(getActivity().checkPermission(android.Manifest.permission.ACCESS_FINE_LOCATION, Process.myPid(),Process.myUid()) == PackageManager.PERMISSION_GRANTED) {

                mFusedLocationClient.getLastLocation()
                        .addOnSuccessListener(getActivity(), new OnSuccessListener<Location>() {
                            @Override
                            public void onSuccess(Location location) {
                                mLastLocation = location;
//                                Log.i("Location", location.toString());
                                if (mLastLocation == null) {
                                    editTextLocation.setEnabled(true);
                                    lat = 0;
                                    lng = 0;
                                    return;
                                } else {
                                    lat = (float) location.getLatitude();
                                    lng = (float) location.getLongitude();

                                }

                                if (!Geocoder.isPresent()) {
                                    Toast.makeText(getContext(),
                                            R.string.no_geocoder_available,
                                            Toast.LENGTH_LONG).show();
                                    return;
                                }

                                // Start service and update UI to reflect new location
                                //Utilities utilities = new Utilities();
                                Utilities.startIntentService(getContext(), mResultReceiver, mLastLocation);
                            }
                        });


        }
        else{
            ActivityCompat.requestPermissions(getActivity(),
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    1);
            Log.i("Location", "not permitted");
        }
*/
    }

    public  void onStart(){
        super.onStart();
    }
    public void onResume()
    {
        super.onResume();
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getActivity().getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int height = displayMetrics.heightPixels;
        int width = displayMetrics.widthPixels;
        Window window = getDialog().getWindow();
        window.setLayout((int)(width * 0.8),(int)(height * 0.55));
        window.setGravity(Gravity.CENTER);
    }

    /*protected void startIntentService() {
        Intent intent = new Intent(getContext(), FetchAddressIntentService.class);
        intent.putExtra(Utilities.RECEIVER, mResultReceiver);
        intent.putExtra(Utilities.LOCATION_DATA_EXTRA, mLastLocation);
        getActivity().startService(intent);
    }*/

    /*private class AddressResultReceiver extends ResultReceiver {
        public AddressResultReceiver(Handler handler) {
            super(handler);
        }

        @Override
        protected void onReceiveResult(int resultCode, Bundle resultData) {

            // Display the address string
            // or an error message sent from the intent service.
            if(resultData != null) {

                mAddressOutput = resultData.getString(Utilities.RESULT_DATA_KEY);
                buttonAddRemark.setVisibility(View.VISIBLE);

                if(!mAddressOutput.equals(getString(R.string.service_not_available)) && !mAddressOutput.equals(""))
                    editTextLocation.setText(mAddressOutput);
                else{
                    new GetAddress().execute("http://maps.googleapis.com/maps/api/geocode/json?latlng=" + Float.toString(lat) + "," + Float.toString(lng));
                }
            }else
                editTextLocation.setEnabled(true);
        }
    }
*/
    private void displayAddressOutput(){
        editTextLocation.setVisibility(View.VISIBLE);
        editTextLocation.setText(mAddressOutput);
    }

    /*private class GetAddress extends AsyncTask<String, Void, String> {
        ProgressDialog asyncDialog = new ProgressDialog(getContext());

        @Override
        protected void onPreExecute() {
            //set message of the dialog
            asyncDialog.setMessage(getString(R.string.loadingtype));
            //show dialog
            asyncDialog.show();
            super.onPreExecute();
        }
        @Override
        protected String doInBackground(String... urls) {
            HttpURLConnection connection = null;
            BufferedReader reader = null;

            try {
                URL url = new URL(urls[0]);
                connection = (HttpURLConnection) url.openConnection();
                connection.connect();


                InputStream stream = connection.getInputStream();

                reader = new BufferedReader(new InputStreamReader(stream));

                StringBuffer buffer = new StringBuffer();
                String line = "";

                while ((line = reader.readLine()) != null) {
                    buffer.append(line+"\n");
                    Log.d("Response: ", "> " + line);   //here u ll get whole response...... :-)

                }

                return buffer.toString();


            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
                try {
                    if (reader != null) {
                        reader.close();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            return null;

        }
        @Override
        protected void onPostExecute(String result) {
            try {
                asyncDialog.dismiss();
                Log.i("Log Remark Address", result);

                JSONObject jsonObject = new JSONObject(result);
                JSONArray jsonResult = jsonObject.getJSONArray("results");
                JSONObject formatted_address = jsonResult.getJSONObject(0);
                String address = formatted_address.getString("formatted_address");

                if(!address.isEmpty())
                    editTextLocation.setText(address);
                else
                    editTextLocation.setText(Float.toString(lat) + ", " + Float.toString(lng));
            }
            catch(Exception ex) {
                ex.printStackTrace();
                dismiss();
            }
        }
    }
*/
    private class InsertLog extends AsyncTask<String, Void, String> {
        ProgressDialog asyncDialog = new ProgressDialog(getContext());
        int returned_id;
        @Override
        protected void onPreExecute() {
            //set message of the dialog
            asyncDialog.setMessage(getString(R.string.loadingtype));
            //show dialog
            asyncDialog.show();
            super.onPreExecute();
        }
        @Override
        protected String doInBackground(String... urls) {

            try {
                String tokenResponse = Utilities.SendTokenPostRequest();
                JSONObject jsonObject = new JSONObject(tokenResponse);
                String token = jsonObject.getString("access_token");
                String tokenType = jsonObject.getString("token_type");

                HashMap<String, String> data = new HashMap<>();
                data.put(Utilities.POLICE_ID, policeId);
                data.put(Utilities.MY_RC, myRc);
                data.put(Utilities.LOG_REMARK, remark);
                data.put(Utilities.LOCATION, address);
                data.put(Utilities.LATITUDE, Float.toString(lat));
                data.put(Utilities.LONGITUDE, Float.toString(lng));
                return Utilities.sendPostRequest(Utilities.LOG, data, token, tokenType);
//                Connection connection = Utilities.getMySqlConnection();
//
//                String query = "INSERT INTO `tb_log`(`police_id`, `myrc`, `remark`, `location`, `lat`, `lng`)"
//                        + " VALUES (?, ?, ?, ?, ?, ?)";
//                //String query = "UPDATE `tb_log` SET `police_id` = ? , `remark` = ?, `location` = ? WHERE `ID` = ?";
//
//                // create the mysql insert preparedstatement
//                PreparedStatement preparedStmt = connection.prepareStatement(query);
//                preparedStmt.setString (1, policeId);
//                preparedStmt.setString(2, myRc);
//                preparedStmt.setString(3, remark);
//                preparedStmt.setString(4, address);
//                preparedStmt.setFloat(5, lat);
//                preparedStmt.setFloat(6,lng);
//
//                returned_id = preparedStmt.executeUpdate();
//
//                Log.i("query", preparedStmt.toString());
//                connection.close();

            }catch (Exception e){
                e.printStackTrace();
                return null;
            }
            /*HashMap<String,String> logData = new HashMap<>();
            logData.put(Utilities.POLICE_ID, policeId);
            logData.put(Utilities.LOG_REMARK, remark);
            logData.put(Utilities.MY_RC, myRc);
            logData.put(Utilities.LOCATION_ADDRESS, address);
            logData.put(Utilities.LATITUDE, Float.toString(lat));
            logData.put(Utilities.LONGITUDE, Float.toString(lng));

            Utilities utilities = new Utilities();
            return utilities.sendPostRequest(urls[0],logData);*/
           // return Integer.toString(returned_id);
        }
        // onPostExecute displays the results of the AsyncTask.
        @Override
        protected void onPostExecute(String result) {
            try {
                    asyncDialog.dismiss();
                if(result!= null && !result.equals("null")) {
                    //Log.i("Log Remark", result);
                    JSONObject jsonObject = new JSONObject(result);
                    if(jsonObject.getString(Utilities.MY_RC).equals(myRc))
                        dismiss();
                    else
                    {
                        Toast.makeText(getContext(), "Something went wrong, failed to add remark.", Toast.LENGTH_LONG).show();
                    }
                }
                else{
                    Toast.makeText(getContext(), "Something went wrong, failed to add remark.", Toast.LENGTH_LONG).show();
                }
                    //Intent intent = new Intent();
                    //getActivity().setResult(RESULT_OK, intent);
               /*
                else{
                    asyncDialog.dismiss();
                    Toast.makeText(getActivity().getApplicationContext(), "Error occurred while submitting your application. Please check your internet.", Toast.LENGTH_LONG).show();
                }*/
            }
            catch(Exception ex) {
                ex.printStackTrace();
                Toast.makeText(getContext(), "Something went wrong, failed to add remark.", Toast.LENGTH_LONG).show();
            }
        }
    }

}
