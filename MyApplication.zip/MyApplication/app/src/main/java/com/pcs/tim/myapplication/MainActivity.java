package com.pcs.tim.myapplication;

import android.Manifest;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Process;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.style.UnderlineSpan;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;

import com.google.zxing.Result;
import com.mysql.jdbc.Util;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;

import javax.net.ssl.HttpsURLConnection;

import me.dm7.barcodescanner.zxing.ZXingScannerView;

public class MainActivity extends AppCompatActivity implements ZXingScannerView.ResultHandler {

    public final static String MY_RC_RMB_ME = "MyRC Remember Me";

    private final static String LOGIN_URL = "http://tris.wmpos.my/DB/login.php";
    static final int REGISTER_REQUEST = 1;

    private SharedPreferences sharePref;
    private String id;
    private String password;
    private String dbResult;
    private EditText editTextID;
    private EditText editTextPassword;
    private CheckBox checkBoxRmb;
    private boolean isScannerView = false;
    private ZXingScannerView scannerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sharePref = getSharedPreferences(Utilities.MY_RC_SHARE_PREF, MODE_PRIVATE);
        boolean rememberMe = sharePref.getBoolean(MY_RC_RMB_ME, false);
        setTitle(getText(R.string.title));

        new GetAppVersion().execute();
        Utilities utilities = new Utilities();
        Log.i("Internet", Boolean.toString(utilities.isOnline(this)));
        if (rememberMe) {
            Intent intent = new Intent(this, MyRCVerification.class);
            startActivity(intent);
            finish();
        }

        TextView textView = (TextView) findViewById(R.id.textViewRegister);
        SpannableString content = new SpannableString(getResources().getString(R.string.register_account));
        content.setSpan(new UnderlineSpan(), 0, content.length(), 0);
        textView.setText(content);
        scannerView = new ZXingScannerView(this);

        Button buttonOffline = (Button) findViewById(R.id.buttonOffline);
        Button buttonLogin = (Button) findViewById(R.id.buttonLogin);
        buttonOffline.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkPermission(Manifest.permission.CAMERA, Process.myPid(), Process.myUid()) == PackageManager.PERMISSION_GRANTED) {
                    //qrScan.initiateScan();
                    setContentView(scannerView);
                    scannerView.setResultHandler(MainActivity.this);
                    if (Build.MANUFACTURER.toLowerCase().contains("huawei"))
                        scannerView.setAspectTolerance(0.5f);
                    scannerView.startCamera();
                    isScannerView = true;

                } else {
                    Toast.makeText(MainActivity.this, "Permission Denied!", Toast.LENGTH_SHORT).show();
                    ActivityCompat.requestPermissions(MainActivity.this,
                            new String[]{Manifest.permission.CAMERA},
                            1);
                }
            }
        });
        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                login();
            }
        });

        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), AccountRegistrationActivity.class);
                startActivityForResult(intent, REGISTER_REQUEST);
            }
        });
    }

    @Override
    protected  void onResume(){
        super.onResume();
        new GetAppVersion().execute();
    }
    @Override
    public void handleResult(Result result) {
        final String myResult = result.getText();
        Log.d("QRCodeScanner", result.getText());
        Log.d("QRCodeScanner", result.getBarcodeFormat().toString());

        if (myResult == null) {
            Toast.makeText(this, "MyRC Not Found", Toast.LENGTH_LONG).show();
        } else {
            //if qr contains data
            try {

                Intent intent = new Intent(this, VerificationResultActivity.class);
                intent.putExtra(Utilities.MY_RC, myResult);
                intent.putExtra("offline", true);
                startActivity(intent);
                finish();

            } catch (Exception e) {
                e.printStackTrace();
                //if control comes here
                //that means the encoded format not matches
                //in this case you can display whatever data is available on the qrcode
                //to a toast
                Toast.makeText(this, myResult, Toast.LENGTH_LONG).show();
            }
        }
    }

//        AlertDialog.Builder builder = new AlertDialog.Builder(this);
//        builder.setTitle("Scan Result");
//        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialog, int which) {
//                scannerView.resumeCameraPreview(MyRCVerification.this);
//            }
//        });
//        builder.setNeutralButton("Visit", new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialog, int which) {
//                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(myResult));
//                startActivity(browserIntent);
//            }
//        });
//        builder.setMessage(result.getText());
//        AlertDialog alert1 = builder.create();
//        alert1.show();


//    @Override
//    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
//        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
//        if (result != null) {
//            //if qrcode has nothing in it
//            if (result.getContents() == null) {
//                Toast.makeText(this, "Result Not Found", Toast.LENGTH_LONG).show();
//            } else {
//                //if qr contains data
//                try {
//                    //converting the data to json
//                    String myRCResult = result.getContents();
//                    Intent intent = new Intent(this, VerificationResultActivity.class);
//                    intent.putExtra(Utilities.MY_RC, myRCResult);
//                    intent.putExtra("offline",true);
//                    startActivity(intent);
//
//                } catch (Exception e) {
//                    e.printStackTrace();
//                    //if control comes here
//                    //that means the encoded format not matches
//                    //in this case you can display whatever data is available on the qrcode
//                    //to a toast
//                    Toast.makeText(this, result.getContents(), Toast.LENGTH_LONG).show();
//                }
//            }
//        }
//
//    }

    //@TargetApi(23)
    private void login() {
        checkBoxRmb = (CheckBox) findViewById(R.id.checkBoxRememberMe);
        editTextID = (EditText) findViewById(R.id.editTextID);
        editTextPassword = (EditText) findViewById(R.id.editTextPassword);
        id = editTextID.getText().toString();
        password = editTextPassword.getText().toString();

        if (!id.trim().isEmpty() && !password.trim().isEmpty()) {
            /*if(checkPassword(id, password)){

                if(checkBoxRmb.isChecked()){
                    SharedPreferences.Editor editor= sharePref.edit();
                    editor.putBoolean(MY_RC_RMB_ME,true);
                    editor.apply();
                }
                Intent intent = new Intent(this, MyRCVerification.class);
                startActivity(intent);
                finish();
            }*/
            if (checkPermission()) {
                new UserLoginTask().execute(Utilities.LOGIN);
            } else {
                ActivityCompat.requestPermissions(MainActivity.this,
                        new String[]{Manifest.permission.INTERNET},
                        1);
            }

        } else {
            editTextID.setError("Invalid ID or Password");
            editTextPassword.setError("Invalid ID or Password");
        }
    }

    private boolean checkPermission() {
        return checkPermission(android.Manifest.permission.INTERNET, Process.myPid(), Process.myUid()) == PackageManager.PERMISSION_GRANTED;
    }

    private class GetAppVersion extends AsyncTask<String, Void, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... urls) {
            try {
                String versionResult = Utilities.Get_Version();
                    JSONObject jsonObject = new JSONObject(versionResult);

                    return jsonObject.getString("version");

            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        // onPostExecute displays the results of the AsyncTask.
        @Override
        protected void onPostExecute(String result) {
            try {
                if (result != null && result != "ERROR") {

                    try {
                        PackageInfo pInfo = getApplicationContext().getPackageManager().getPackageInfo(getPackageName(), 0);
                        String version = pInfo.versionName;

                        if (!version.equals(result)) {
                            AlertDialog.Builder adb = new AlertDialog.Builder(MainActivity.this);
                            adb.setTitle("Latest version available");
                            adb.setMessage("Please update to latest version");
                            adb.setIcon(R.mipmap.ic_tris_logo);
                            adb.setPositiveButton("Update", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    try {
                                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + Utilities.PACKAGE_NAME)));
                                    } catch (android.content.ActivityNotFoundException anfe) {
                                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(Utilities.APP_URL)));
                                    }
                                } });
                            adb.setCancelable(false);
                            AlertDialog alert = adb.create();
                            alert.show();
                        }

                    } catch (PackageManager.NameNotFoundException e) {
                        e.printStackTrace();
                    }
                } else {
                    Toast.makeText(getApplicationContext(), "No internet access.", Toast.LENGTH_LONG).show();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }

        }
    }

    private class UserLoginTask extends AsyncTask<String, Void, String> {
        ProgressDialog asyncDialog = new ProgressDialog(MainActivity.this);

        @Override
        protected void onPreExecute() {
            //set message of the dialog
            asyncDialog.setMessage(getString(R.string.loadingtype));
            //show dialog
            asyncDialog.show();
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... params) {

            try {
                String tokenResponse = Utilities.SendTokenPostRequest();
                JSONObject jsonObject = new JSONObject(tokenResponse);
                String token = jsonObject.getString("access_token");
                String tokenType = jsonObject.getString("token_type");
                HashMap<String,String> data = new HashMap<>();
                data.put(Utilities.POLICE_ID , id);
                data.put(Utilities.PASSWORD, Utilities.getMD5Hash(password));
                return Utilities.sendPostRequest(Utilities.LOGIN, data, token, tokenType);

//                Connection connection = Utilities.getMySqlConnection();
//                Statement statement = connection.createStatement();
//
//                String query = "select `police_id`, `status` from `tb_enforcement` where `police_id`= '" + id + "' and `password`='" + Utilities.getMD5Hash(password) + "' and `status` = 'Y'";
//
//                ResultSet result = statement.executeQuery(query);
//
//                if (result.next()) {
//                    dbResult = "success";
//                } else
//                    dbResult = "fail";

            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }


        }

        @Override
        protected void onPostExecute(String result) {

            asyncDialog.dismiss();
            try {
          // Log.i("Login result", result);

                SharedPreferences.Editor editor = sharePref.edit();

                if (result != null) {
                    JSONObject jsonObject = new JSONObject(result);
                    String police_id = jsonObject.getString(Utilities.POLICE_ID);
                    String police_photo = jsonObject.getString(Utilities.PHOTO);
                    String police_name = jsonObject.getString(Utilities.POLICE_NAME);
                    String police_station = jsonObject.getString(Utilities.POLICE_STATION);
                    String police_agency = jsonObject.getString(Utilities.POLICE_AGENCY);
                    String police_rank = jsonObject.getString(Utilities.POLICE_RANK);
                    String police_state = jsonObject.getString(Utilities.POLICE_STATE);
                    String police_dept = jsonObject.getString(Utilities.POLICE_DEPARTMENT);
                    String police_hp = jsonObject.getString(Utilities.POLICE_MOBILE);
                    String police_ic = jsonObject.getString(Utilities.IC_NO);
                    String status = jsonObject.getString(Utilities.STATUS);

                    if (police_id.equals(id)) {
                        if (checkBoxRmb.isChecked()) {

                            editor.putBoolean(MY_RC_RMB_ME, true);

                        }
                        if(police_photo != null && !police_photo.isEmpty())
                            editor.putString(Utilities.LOGIN_POLICE_PHOTO, police_photo);
                        editor.putString(Utilities.LOGIN_POLICE_AGENCY, police_agency);
                        editor.putString(Utilities.LOGIN_POLICE_DEPT, police_dept);
                        editor.putString(Utilities.LOGIN_POLICE_IC, police_ic);
                        editor.putString(Utilities.LOGIN_POLICE_NAME, police_name);
                        editor.putString(Utilities.LOGIN_POLICE_STATION, police_station);
                        editor.putString(Utilities.LOGIN_POLICE_MOBILE, police_hp);
                        editor.putString(Utilities.LOGIN_POLICE_STATE, police_state);
                        editor.putString(Utilities.LOGIN_POLICE_RANK, police_rank);
                        editor.putString(Utilities.LOGIN_POLICE_ID, id);
                        editor.putString(Utilities.LOGIN_POLICE_PWD, password);
                        editor.putString(Utilities.LOGIN_POLICE_STATUS,status);
                        editor.putBoolean(Utilities.LOGGED_IN, true);
                        editor.apply();

                        Intent intent = new Intent(getApplicationContext(), MyRCVerification.class);
                        startActivity(intent);
                        finish();
                    }
                }

                else {
                    editTextID.setError(getString(R.string.err_incorrect_password_or_id));
                    editTextPassword.setError(getString(R.string.err_incorrect_password_or_id));
                    editTextID.requestFocus();
                }
                /*JSONObject jsonObject = new JSONObject(result);
                SharedPreferences.Editor editor = sharePref.edit();

                if (jsonObject.getBoolean("success")) {
                    if(checkBoxRmb.isChecked()) {

                        editor.putBoolean(MY_RC_RMB_ME, true);

                    }
                    editor.putString(Utilities.LOGIN_POLICE_ID, id);
                    editor.putBoolean(Utilities.LOGGED_IN, true);
                    editor.apply();
                    Intent intent = new Intent(getApplicationContext(), MyRCVerification.class);
                    startActivity(intent);
                    finish();
                }
                else {
                    editTextID.setError(jsonObject.getString("error"));
                    editTextPassword.setError(jsonObject.getString("error"));
                    editTextID.requestFocus();
                }*/
            } catch (Exception ex) {
                //Log.e("MyRC Login", ex.toString());
                if(result == null){
                    Toast.makeText(getApplicationContext(), "Account is yet to be approved or username and password not match.", Toast.LENGTH_LONG).show();
                }
                else if(result.isEmpty())
                    Toast.makeText(getApplicationContext(), "Server unavailable currently, please try again later", Toast.LENGTH_LONG).show();
                else{
                    Toast.makeText(getApplicationContext(), "Account is yet to be approved or username and password not match.", Toast.LENGTH_LONG).show();
                }
            }

            // }

        }
    }




    private String getPostDataString(HashMap<String, String> params) throws UnsupportedEncodingException {
        StringBuilder result = new StringBuilder();
        boolean first = true;
        for (Map.Entry<String, String> entry : params.entrySet()) {
            if (first)
                first = false;
            else
                result.append("&");

            result.append(URLEncoder.encode(entry.getKey(), "UTF-8"));
            result.append("=");
            result.append(URLEncoder.encode(entry.getValue(), "UTF-8"));
        }

        return result.toString();
    }

    @Override
    public void onBackPressed() {
        // Write your code here
        if (isScannerView) {
            scannerView.stopCamera();
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
            //setContentView(R.layout.activity_my_rc_verification);
            isScannerView = false;
            finish();
        } else
            super.onBackPressed();
        //

    }
}

